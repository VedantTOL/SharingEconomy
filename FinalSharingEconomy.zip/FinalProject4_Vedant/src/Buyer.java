import java.io.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.util.zip.DataFormatException;
/**
 * The buyer class that allows the buyer to perform all the necessary actions within the marketplace. Methods within
 * this class allow the buyer to purchase products, add them to their cart, remove them from their cart, purchase their
 * whole cart, view their cart, and view their purchases. Methods within this class also write to the corresponding files
 * so that data is preserved between logging out and logging in.
 *
 *
 * @author Roger, Somansh, Ethan, Vedant
 * @version June 13, 2022
 */

public class Buyer extends User {
    private double balance;
    private ArrayList<ProductPurchase> shoppingCart;
    private ArrayList<ProductPurchase> purchases;

    public Buyer(int uniqueIdentifier, String email, String password, String name, int age, double balance) {
        super(uniqueIdentifier, email, password, name, age, -1);
        this.balance = balance;
        this.shoppingCart = new ArrayList<ProductPurchase>();
        this.purchases = new ArrayList<ProductPurchase>();
    }

    public Buyer(int uniqueIdentifier) throws NoAccountError{
        super(uniqueIdentifier);
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public ArrayList<ProductPurchase> getShoppingCart() {
        return shoppingCart;
    }

    public void setShoppingCart(ArrayList<ProductPurchase> shoppingCart) {
        this.shoppingCart = shoppingCart;
    }

    public ArrayList<ProductPurchase> getPurchases() {
        return purchases;
    }

    public void setPurchases(ArrayList<ProductPurchase> purchases) {
        this.purchases = purchases;
    }

    public ArrayList<Buyer> readBuyerDatabase() throws DataFormatException, IOException {
        ArrayList<Buyer> database = new ArrayList<Buyer>();
        ArrayList<Product> productDatabase = getProductDatabase();

        String line;
        Buyer buyer = null;

        BufferedReader bfr = null;
        try {
            bfr = new BufferedReader(new FileReader("./src/BuyerDatabase.txt"));
            while (true) {
                line = bfr.readLine();
                if (line == null) {
                    break;
                }
                char identifier = line.charAt(0);

                if (identifier == '*') {
                    try {
                        buyer = new Buyer(Integer.parseInt(line.split(" ")[1]));
                        database.add(buyer);
                    } catch (NoAccountError e) {
                        return null;
                    }

                } else if (identifier == '+') {
                    line = line.substring(2);
                    String[] cartList = line.split(", ");
                    for (String productID: cartList) {
                        try {
                            int tempID = Integer.parseInt(productID.split(":")[0]);
                            int tempQuantity = Integer.parseInt(productID.split(":")[1]);
                            buyer.shoppingCart.add(new ProductPurchase(tempID, tempQuantity));
                        } catch (NumberFormatException e){

                        }
                        /*
                        for (Product product: productDatabase) {
                            if (tempID == product.getUniqueID()){
                                buyer.shoppingCart.add(new ProductPurchase(product.getUniqueID(), tempQuantity));
                            }
                        }
                        */

                    }

                } else if (identifier == '-') {
                    line = line.substring(2);
                   // System.out.println(line);
                    String[] purchasedList = line.split(", ");
                    for (String productID: purchasedList) {
                        try {
                            int tempID = Integer.parseInt(productID.split(":")[0]);

                            int tempQuantity = Integer.parseInt(productID.split(":")[1]);
                            buyer.purchases.add(new ProductPurchase(tempID, tempQuantity));
                        } catch (NumberFormatException e) {

                        }
                        /*
                        for (Product product: productDatabase) {
                            if (tempID == product.getUniqueID()){
                        }
                         */
                    }
                }

            }


        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return database;

    }

    public ArrayList<Seller> readSellerDatabase() {
        File f;
        FileReader fr;
        BufferedReader bfr;
        String line;
        ArrayList<Seller> database= new ArrayList<Seller>();
        Seller seller;
        Store store;
        Product product;
        int sellerIndex = -1;
        int storeIndex = -1;

        try {
            bfr = new BufferedReader(new FileReader(new File("./src/SellerDatabase.txt")));

            while (true) {
                line = bfr.readLine();
                //System.out.println();
                if (line == null) {
                    break;
                }
                char identifier = line.charAt(0);
                if (identifier == 42) {
                    sellerIndex++;
                    storeIndex = -1;
                    try {
                        seller = new Seller(Integer.parseInt(line.split(" ")[1]));
                        database.add(seller);
                    } catch (NoAccountError e) {
                        return null;
                    }
                } else if (identifier == 43) {
                    storeIndex++;
                    store = new Store(line.split(" ")[1]);
                    database.get(sellerIndex).addStore(store);
                } else {
                    try {
                        product = new Product(line.split(", "));
                        //System.out.println(storeIndex);
                        database.get(sellerIndex).getStores().get(storeIndex).addProduct(product);
                    } catch (DataFormatException e) {
                        System.out.println("Seller Database Malformed!");
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return database;
    }

    public ArrayList<Product> getProductDatabase() {
        ArrayList<Seller> database= readSellerDatabase();
        ArrayList<Product> productDatabase = new ArrayList<Product>();
        if (database == null) {
            return null;
        }
        for (Seller seller: database) {
            for (Store store : seller.getStores()) {
                for (Product product : store.getProducts()) {
                    productDatabase.add(product);
                }
            }
        }
        return productDatabase;
    }

    public ArrayList<Product> viewMarketPlace(int choice, Scanner scanner) {
        if (choice == 1) {
            ArrayList<Seller> sortProducts = readSellerDatabase();
            if (sortProducts == null) {
                return null;
            }

            int sort;
            do {
                System.out.println("How would you like to sort the marketplace?\n1. Price \n2. Quantity\n"+
                        "3. Name");
                String sorting = scanner.nextLine();
                sort = readInt(sorting);
            } while (sort == -1);

            do {
                if (sort == 1) {
                    ArrayList<Product> productPrices= new ArrayList<Product>();
                    for (Seller seller: sortProducts) {
                        for (Store store : seller.getStores()) {
                            for (Product product : store.getProducts()) {
                                productPrices.add(product);
                            }
                        }
                    }
                    Collections.sort(productPrices, Comparator.comparingDouble(Product::getPrice));
                    if (productPrices.size() ==0) {
                        break;
                    }
                    return productPrices;

                } else if (sort == 2) {
                    ArrayList<Product> productQuantities = new ArrayList<>();
                    for (Seller seller: sortProducts) {
                        for (Store store : seller.getStores()) {
                            for (Product product : store.getProducts()) {
                                productQuantities.add(product);
                            }
                        }
                    }
                    if (productQuantities.size() ==0) {
                        break;
                    }

                    Collections.sort(productQuantities, Comparator.comparingInt(Product::getQuantityForPurchase) );

                    return productQuantities;

                } else if (sort == 3) {
                    ArrayList<Product> productNames = new ArrayList<Product>();
                    for (Seller seller: sortProducts) {
                        for (Store store : seller.getStores()) {
                            for (Product product : store.getProducts()) {
                                productNames.add(product);
                            }
                        }
                    }
                    if (productNames.size() ==0) {
                        break;
                    }

                    Collections.sort(productNames, Comparator.comparing(Product::getName));

                    return productNames;

                } else {
                    System.out.println("Enter a valid number to sort the marketplace!");
                }
            } while (sort != 1 && sort != 2 && sort != 3);

        } else if (choice == 2) {
            ArrayList<Seller> searchProducts = readSellerDatabase();

            int search;
            do {
                System.out.println("What would you like to search for?\n1.Name \n2. Store\n3. Description");
                String searching = scanner.nextLine();
                search = readInt(searching);
            } while (search == -1);

            do{
                if (search == 1) {
                    System.out.println("Enter the name of the product you want to buy.");
                    String nameProd = scanner.nextLine();

                    ArrayList<Product> nameProduct = new ArrayList<>();

                    for (Seller seller : searchProducts) {
                        for (Store store : seller.getStores()) {
                            for (Product product : store.getProducts()) {
                                if (product.getName().contains(nameProd)) {
                                    nameProduct.add(product);
                                }
                            }
                        }
                        Collections.sort(nameProduct,Comparator.comparing(Product::getName));
                        return nameProduct;
                    }
                }

                if (search == 2) { // Store
                    System.out.println("Enter the name of the store you want to buy from.");
                    String storeProd = scanner.nextLine();

                    Store storeName = null; //is it okay is i put

                    for (Seller seller : searchProducts) {
                        for (Store store : seller.getStores()) {
                            if (store.getStoreName().equals(storeProd)) {
                                storeName = store;
                            }
                        }
                    }

                    return storeName.getProducts();
                }
                if (search == 3) { // description

                    System.out.println("Enter the description of the product you want to buy.");
                    String prodDescription = scanner.nextLine();

                    ArrayList<Product> descriptionProd = new ArrayList<Product>();

                    for (Seller seller : searchProducts) {
                        for (Store store : seller.getStores()) {
                            for (Product product : store.getProducts()) {
                                if (product.getDescription().contains(prodDescription)) {
                                    //descriptionProd.add(product); // should i just do product or product.getName()
                                    descriptionProd.add(product);
                                }
                            }
                        }
                    }
                    Collections.sort(descriptionProd, Comparator.comparing(Product::getName));


                    return descriptionProd;
                }
            } while(search != 1 && search != 2 && search != 3);
        }
        return null;
    }

    public void writeToBuyer() throws DataFormatException, IOException {
        ArrayList<Buyer> buyerDatabase = readBuyerDatabase();
        if (buyerDatabase.size() != 0) {
            buyerDatabase.remove(this.getUniqueIdentifier());
            buyerDatabase.add(this.getUniqueIdentifier(), this);
        } else {
            buyerDatabase.add(this.getUniqueIdentifier(),this);
        }

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("./src/BuyerDatabase.txt"));
            for (Buyer buyer : buyerDatabase) {
                String temp = String.format("* %d\n", buyer.getUniqueIdentifier());
                bw.write(temp);
                if (buyer.getShoppingCart() != null) {
                    bw.write("+ ");
                    for (ProductPurchase productPurchase : buyer.shoppingCart) {
                        bw.write(productPurchase.toString());
                        bw.write(", ");
                        bw.flush();
                    }
                    bw.write("\n");
                }
                if (buyer.getPurchases() != null && !buyer.getPurchases().isEmpty()) {
                    bw.write("- ");
                    for (ProductPurchase productPurchase : buyer.purchases) {
                        bw.write(productPurchase.toString());
                        bw.write(", ");
                        bw.flush();
                    }
                    bw.write("\n");
                } else {
                    System.out.println("You have no purchases!"); //this was added later.

                }
                bw.flush();
            }
            bw.close();
        } catch (IOException e) {
            System.out.println("Database Malformed");
        }
    }

    public Product viewProduct(ArrayList<Product> productList, int productNum) {
        Product selected = productList.get(productNum-1);
        System.out.println(selected.productPage());
        return selected;
    }

    public Store viewStore(Product product) {
        ArrayList<Seller> fetchStore = readSellerDatabase();
        for (Seller seller: fetchStore) {
            for (Store store : seller.getStores()) {
                for (Product products : store.getProducts()) {
                    if (product.getUniqueID() == products.getUniqueID()) {
                        return store;
                    }
                }
            }
        }
        return null;
    }

    public void addToShoppingCart(Product product, Store store, int quantity) {
        try {
            for (int i = 0; i < store.getProducts().size(); i++) {
                if (store.getProducts().get(i).getUniqueID() == product.getUniqueID() && product.getQuantityForPurchase() > 0) {
                    shoppingCart.add(new ProductPurchase(product.getUniqueID(), quantity));
                } else {
                    System.out.println("This product does not exist in our store!");
                }
            }
        } catch (NullPointerException e) {
            System.out.println("This store has no products left!");
        }
    }

    public void removeFromShoppingCart(Product product) {
        int index = 0;
        for (int i = 0; i < shoppingCart.size(); i++) {
            if (shoppingCart.get(i).getUniqueID() == product.getUniqueID()) {
                shoppingCart.remove(i);
                System.out.printf("%s has been removed from the shopping cart!\n", product.getName());
                index++;
            }
        }
        if (index == 0) {
            System.out.printf("%s is not in your cart.\n", product.getName());
        }
    }

    public void writeToDatabase(boolean newSeller, ArrayList<Seller> database) {
        //ArrayList<Seller> database = readSellerDatabase();
        if (database == null) {
            return;
        }

        ArrayList<Seller> removeDuplicates = new ArrayList<Seller>();
        for (Seller seller: database) {
            if (seller.getSellerIndex() != -1) {
                removeDuplicates.add(seller.getSellerIndex(), seller);
            }
        }

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("./src/SellerDatabase.txt"));
            for (Seller seller : removeDuplicates) {
                String temp = String.format("* %d\n", seller.getSellerIndex());
                bw.write(temp);
                if (seller.getStores() != null) {
                    for (Store store : seller.getStores()) {
                        bw.write(String.format("+ %s\n", store.getStoreName()));
                        for (Product product : store.getProducts()) {
                            bw.write(product.toDatabase());
                            bw.write("\n");
                        }
                    }
                }
                bw.flush();
            }
            bw.close();
        } catch (IOException e) {
            System.out.println("Database Malformed");
        }
    }

    public void buyProduct(Product product, int numProductsForPurchase, Store store, Scanner scanner) {
        boolean success = false;
        int index = 0;
        for (int i = 0; i < store.getProducts().size(); i++) {
            if (store.getProducts().get(i).getUniqueID() == product.getUniqueID()) {
                index = store.getProducts().indexOf(store.getProducts().get(i));
            }
        }
        if (product.getQuantityForPurchase() > 0) {
            double total = product.getPrice() * numProductsForPurchase;
            if (product.getQuantityForPurchase() >= numProductsForPurchase) {
                if (balance >= total) {
                    balance -= total;
                    product.setQuantityForPurchase(product.getQuantityForPurchase() - numProductsForPurchase);
                    store.getProducts().get(index).setQuantityForPurchase(product.getQuantityForPurchase());
                    System.out.printf("%d of %s have been bought for $%.2f.\n", numProductsForPurchase, product.getName(), total);
                    product.setQuantitySold(product.getQuantitySold() + numProductsForPurchase);
                    purchases.add(new ProductPurchase(product.getUniqueID(), numProductsForPurchase));

                    success = true;
                } else {
                    System.out.println(super.getName() + " cannot afford " + product.getName());
                }

            } else if (product.getQuantityForPurchase() == numProductsForPurchase) {
                if (balance >= total) {
                    balance -= total;
                    product.setQuantityForPurchase(0);
                    store.getProducts().get(index).setQuantityForPurchase(0);
                    store.getProducts().remove(product);
                    System.out.printf("You got the last %d %ss available!\n", product.getQuantityForPurchase(), product.getName());
                    purchases.add(new ProductPurchase(product.getUniqueID(), numProductsForPurchase));
                    success = true;
                } else {
                    System.out.println(super.getName() + " cannot afford " + product.getName());
                }

            } else if (product.getQuantityForPurchase() < numProductsForPurchase) {
                int productsavail = product.getQuantityForPurchase() + 1;
                if (product.getQuantityForPurchase() == 1) {
                    System.out.println("There is only " + productsavail + " " + product.getName() + "left in this store!");
                } else {
                    System.out.println("There are only " + productsavail + " " + product.getName() + "s left in this store!");
                }
                System.out.println("Would you like to purchase the remaining number?");
                String yesOrNo = scanner.nextLine();
                if (yesOrNo.equalsIgnoreCase("Yes")) {
                    if (balance >= total) {
                        balance -= total;
                        product.setQuantityForPurchase(0);
                        store.getProducts().get(index).setQuantityForPurchase(0);
                        store.getProducts().remove(product);
                        System.out.printf("You got the last %d %ss available!\n", product.getQuantityForPurchase(), product.getName());
                        purchases.add(new ProductPurchase(product.getUniqueID(), numProductsForPurchase));
                        success = true;
                    } else {
                        System.out.println(super.getName() + " cannot afford " + product.getName());
                    }
                }
            }
        } else {
            System.out.printf("%s is out of stock!\n", product.getName());
        }
        if (success) {
            ArrayList<Seller> databaseUpdate = readSellerDatabase();
            Seller toEdit = null;
            boolean completed = false;
            for (Seller seller: databaseUpdate) {
                for (Store storeX: seller.getStores()) {
                    for (Product productX: storeX.getProducts()) {
                        if (productX.getUniqueID() == product.getUniqueID()) {
                            toEdit = seller;
                            ArrayList<Store> tempStores = toEdit.getStores();
                            Store tempStore = storeX;

                            ArrayList<Product> tempProduct = tempStore.getProducts();
                            Product tempBuy = productX;
                            tempProduct.remove(tempBuy);

                            tempProduct.add(product);
                            tempStore.setProducts(tempProduct);

                            tempStores.remove(tempStore);
                            tempStores.add(tempStore);
                            toEdit.setStores(tempStores);
                            completed = true;
                            break;
                        }
                        if (completed) break;
                    }
                    if (completed) break;
                }
                if (completed) break;
            }
            databaseUpdate.remove(toEdit.getSellerIndex());
            databaseUpdate.add(toEdit.getSellerIndex(), toEdit);
            this.writeToDatabase(false, databaseUpdate);
        }
    }

    public int purchaseCart() {
        ArrayList<ProductPurchase> shoppingCartFile = viewCart();
        if (shoppingCartFile == null) {
            shoppingCartFile = new ArrayList<ProductPurchase>();
        }

        shoppingCart.addAll(shoppingCartFile);

        ArrayList<Seller> sellers = readSellerDatabase();
        double totalSum = 0;
        for (ProductPurchase productPurchase : shoppingCart) {
            totalSum = totalSum + (productPurchase.getPrice() * productPurchase.getOrderQuantity());
        }

        if (totalSum <= balance) {
            for (ProductPurchase productPurchase : shoppingCart) {
                if (productPurchase.getOrderQuantity() <= productPurchase.getQuantityForPurchase()) {
                    productPurchase.setQuantityForPurchase(productPurchase.getQuantityForPurchase() - productPurchase.getOrderQuantity());
                }
            }
            ArrayList<Seller> updated = readSellerDatabase();


            Seller toEdit = null;
            for (Seller seller: updated ) {
                for (Store store: seller.getStores()) {
                    for (ProductPurchase productPurchase : shoppingCart) {
                        for (Product product : store.getProducts()) {
                            if (productPurchase.getUniqueID() == product.getUniqueID()) {
                                toEdit = seller;
                                ArrayList<Store> tempStores = toEdit.getStores();
                                Store tempStore = store;

                                ArrayList<Product> tempProduct = tempStore.getProducts();
                                Product tempBuy = productPurchase;
                                tempProduct.remove(product);

                                tempProduct.add(tempBuy);
                                tempStore.setProducts(tempProduct);

                                tempStores.remove(store);
                                tempStores.add(tempStore);
                                seller.setStores(tempStores);
                                break;
                            }
                        }
                    }
                }
            }
            updated.remove(toEdit.getSellerIndex());
            updated.add(toEdit.getSellerIndex(), toEdit);

            purchases.addAll(shoppingCart);
            shoppingCart.removeAll(purchases);
            balance = balance - totalSum;
            System.out.println("Thank you for your purchases!");
            writeToDatabase(false, updated);
            return 0;

        } else if (totalSum > balance) {
            System.out.println("ERROR! Transaction denied. Your balance is less than the total price of your cart.");
            System.out.println("You will need to remove products until the total price is less than or equal to your balance");
            System.out.printf("Total Price: %.2f\n", totalSum);
            System.out.printf("Balance: %.2f\n", balance);
            return 1;
        }

        return 0;
    }


    public ArrayList<ProductPurchase> viewCart() {
        ArrayList<ProductPurchase> shoppingCart = null;

        try {
            ArrayList<Buyer> buyers = readBuyerDatabase();
            for (Buyer buyer : buyers) {
                if (buyer.getUniqueIdentifier() == getUniqueIdentifier()) {
                    shoppingCart = buyer.getShoppingCart();
                }
            }

        } catch (IOException | DataFormatException e) {
            throw new RuntimeException();
        }
        return shoppingCart;
    }
    public ArrayList<ProductPurchase> viewPurchases() {
        ArrayList<ProductPurchase> purchases = null;

        try {
            ArrayList<Buyer> buyers = readBuyerDatabase();
            for (Buyer buyer : buyers) {
                if (buyer.getUniqueIdentifier() == getUniqueIdentifier()) {
                    purchases = buyer.getPurchases();
                }
            }

        } catch (IOException | DataFormatException e) {
            throw new RuntimeException();
        }
        return purchases;
    }

    public Seller shopBySeller(Scanner scanner) {

        // add a do while to take into account "No seller found with the name: "

        ArrayList<Seller> shopSeller = readSellerDatabase();

        System.out.println("What is the name of the seller you want to buy from?");
        String nameSeller = scanner.nextLine();


        // Find the seller object that matches the entered name
        Seller seller = null;
        for (Seller s : shopSeller) {
            if (s.getName().equalsIgnoreCase(nameSeller)) {
                seller = s;
                return seller;
            }
        }

        if (seller == null) {
            System.out.println("No seller found with the name: " + nameSeller);
        }

        return null;
    }


    public ArrayList<Product> shopByStore(Seller seller, Scanner scanner) {

        ArrayList<Store> shopSeller = seller.getStores();

        System.out.println("Enter the name of the shop you want to see products for:");
        String shopName = scanner.nextLine();

        // Find the store object that matches the entered name
        for (Store store : shopSeller) {
            if (shopName.equalsIgnoreCase(store.getStoreName())) {
                return store.getProducts();
            }
        }

        return null;
    }

    public static int readInt(String input) {
        int result;
        try {
            result = Integer.parseInt(input);
            return result;
        } catch (NumberFormatException e) {
            System.out.println("Please enter a valid Integer!");
            return -1;
        }
    }

}